import os
import sys
import time
import serial
from datetime import datetime
from App import *

from PyQt5 import QtGui, QtCore, QtWidgets
from PyQt5.QtGui import QStandardItemModel, QStandardItem
from PyQt5.QtWidgets import QColumnView, QAbstractItemView

import RPi.GPIO as GPIO
import pyrebase
import dht11

import board
import busio
import adafruit_ssd1306
from PIL import Image, ImageDraw, ImageFont

ser = serial.Serial('/dev/ttyACM0', 9600)

model = QStandardItemModel()
model.setColumnCount(1)
sensor, distancia, temperatura, humedad = 0, 0, 0, 0
luz, presencia = "APAGADO", "APAGADO"

config = {
	"apiKey": "AIzaSyCrhEWGg1l2037XkFFdIWU3Xxw0ccuwZz8",
    "authDomain": "arquitectura-de-coomputadoras.firebaseapp.com",
    "databaseURL": "https://arquitectura-de-coomputadoras-default-rtdb.firebaseio.com",
    "projectId": "arquitectura-de-coomputadoras",
    "storageBucket": "arquitectura-de-coomputadoras.appspot.com",
    "messagingSenderId": "131149093979",
    "appId": "1:131149093979:web:b551b72dad05bfc328737e",
    "measurementId": "G-QG9LVJDRYE"
}

firebase = pyrebase.initialize_app(config)
db = firebase.database()

i2c = busio.I2C(board.SCL, board.SDA)
display = adafruit_ssd1306.SSD1306_I2C(128, 64, i2c)
display.fill(0)
display.show()
image = Image.new("1", (128, 64))
draw = ImageDraw.Draw(image)
font = ImageFont.load_default()

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.cleanup()

#DISTANCIA
GPIO.setup(11,GPIO.OUT) #Trig
GPIO.setup(8,GPIO.IN) #Echo

#LUZ
GPIO.setup(26,GPIO.IN)

#PRESENCIA
GPIO.setup(6,GPIO.IN)

#TEMPERATURA/HUMEDAD
instancia = dht11.DHT11(pin = 4) 

class Ui_MainWindow(QtWidgets.QMainWindow,Ui_MainWindow):
    def __init__(self, *args, **kwargs):
        QtWidgets.QMainWindow.__init__(self, *args, **kwargs)
        self.setupUi(self)

        self.SensoresShow.setModel(model)
        self.BtnDistancia.clicked.connect(self.RbDistancia)
        self.BtnTemperatura.clicked.connect(self.RbTemperatura)
        self.BtnHumedad.clicked.connect(self.RbHumedad)
        self.BtnLuz.clicked.connect(self.RbLuz)
        self.BtnPresencia.clicked.connect(self.RbPresencia)
        self.Minimizar.clicked.connect(self.showMinimized)
        self.Maximizar.clicked.connect(self.toggleMaximized)
        self.Cerrar.clicked.connect(self.close)
        
        self.loop()
    
    def toggleMaximized(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()
    
    def loop(self):
        fecha = datetime.now()
        formato = fecha.strftime("%m/%d, %H:%M")
        
        global model, distancia, temperatura, humedad, luz, presencia
        tmp_distancia = SensorDistancia()
        if tmp_distancia <= 400: distancia = tmp_distancia
        resultadoDHT = SensorHumedadTemp()
        l = SensorLuz()
        p = SensorPresencia()
        
        try:
            tmp_temperatura, tmp_humedad = resultadoDHT
            if tmp_temperatura is not None: temperatura = tmp_temperatura
            if tmp_humedad is not None: humedad = tmp_humedad
        except: print("")
            
        if sensor == 4: 
            model.appendRow([QStandardItem("{:0>4}".format(str(distancia)) + " cm,          " + formato)])
            ser.write((str(distancia) + "cm").encode())
        elif sensor == 0: 
            model.appendRow([QStandardItem("{:0>4}".format(str(temperatura)) + " °C,            " + formato)])
            ser.write((str(temperatura) + ":C").encode())
        elif sensor == 1: 
            model.appendRow([QStandardItem("{:0>4}".format(str(humedad)) + " %,         " + formato)])
            ser.write((str(humedad) + "%").encode())
        elif sensor == 2: 
            if l == 1: 
                luz = "ENCENDIDO"
                self.LuzShow.display(1)
                ser.write(b'ENCENDIDO')
            else: 
                luz = "APAGADO"
                self.LuzShow.display(0)
                ser.write(b'APAGADO')
        elif sensor == 3: 
            if p == 1:
                presencia = "ENCENDIDO"
                self.PresenciaShow.setValue(1)
                ser.write(b'ENCENDIDO')
            else:
                presencia = "APAGADO"
                self.PresenciaShow.setValue(0)
                ser.write(b'APAGADO')
        
        DisplayOled(distancia, temperatura, humedad, luz, presencia)
        Firebase(distancia, temperatura, humedad, l, p)
        QtCore.QTimer.singleShot(1000, self.loop)
    
    def RbTemperatura(self): 
        global model, sensor
        sensor = 0
        model = self.SensoresShow.model()
        model.clear()
        self.NameSensores.setText("TEMPERATURA")
    
    def RbHumedad(self): 
        global model, sensor
        sensor = 1
        model = self.SensoresShow.model()
        model.clear()
        self.NameSensores.setText("HUMEDAD")
    
    def RbLuz(self): 
        global model, sensor
        sensor = 2
        model = self.SensoresShow.model()
        model.clear()
    
    def RbPresencia(self): 
        global model, sensor
        sensor = 3
        model = self.SensoresShow.model()
        model.clear()
    
    def RbDistancia(self):
        global model, sensor
        sensor = 4
        model = self.SensoresShow.model()
        model.clear()
        self.NameSensores.setText("DISTANCIA")

def SensorDistancia():
    GPIO.output(11,GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(11,GPIO.LOW)

    while GPIO.input(8) == 0:
        pulsoI = time.time()
    while GPIO.input(8) == 1:
        pulsoF = time.time()

    duracion = pulsoF - pulsoI
    distancia = round((17150 * duracion),1)
    return distancia

def SensorHumedadTemp():
    resultado = instancia.read()
    if resultado.is_valid():
        Tempertura = "%-3.1f" % resultado.temperature
        Humedad = "%-3.1f" % resultado.humidity
        return float(Tempertura), float(Humedad)

def SensorLuz():
    if GPIO.input(26) == GPIO.HIGH: 
        return 0
    else: 
        return 1

def SensorPresencia():
    if GPIO.input(6) == GPIO.HIGH: 
        return 1
    else: 
        return 0

def Firebase(distancia, temperatura, humedad, luz, presencia):
    db.child("Sensor").child("HC-SR04").update({"Distancia": distancia})
    db.child("Sensor").child("DHT-11").update({"Temperatura": temperatura})
    db.child("Sensor").child("DHT-11").update({"Humedad": humedad})
    db.child("Sensor").child("MH-LM393").update({"Luz": luz})
    db.child("Sensor").child("KY-026").update({"Flama": presencia})

def DisplayOled(distancia, temperatura, humedad, luz, presencia):
    
    # Resetear
    display.fill(0)
    display.show()
    image = Image.new("1", (128, 64))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    
    # Valores
    draw.text((4, 10), "Distancia: " + str(distancia) + "cm", font = font, fill = 255)
    draw.text((4, 20), "Temperatura: " + str(temperatura) + "°C", font = font, fill = 255)
    draw.text((4, 30), "Humedad: " + str(humedad) + "%", font = font, fill = 255)
    draw.text((4, 40), "Luz: " + luz, font = font, fill = 255)
    draw.text((4, 50), "Flama: " + presencia, font = font, fill = 255)
    display.image(image)
    display.show()

if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = Ui_MainWindow()
    window.show()
    app.exec_()
